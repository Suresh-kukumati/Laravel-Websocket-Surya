function function1([a, b, c], { d }, ...e) {
  console.log(a);
  console.log(b);
  console.log(c);
  console.log(d);
  console.log(e);
}

function1(["a", "b", "c"], { d: "dValue" }, "extra1", "extra2");

// let a = [1, 2, 3];
// let b = [1, 2, 3];
// let c = "1,2,3";
// console.log(a == c);
// console.log(b == c);
// console.log(a == b);

// const arr = ["name"];
// const obj = {};
// obj.name = "Hi";
// obj[arr] = "how?";
// console.log(obj.name);

// for (var x = 0; x <= 5; x++) {
//   printVal(x);
// }
// let printVal = (z) => {
//   setTimeout(() => {
//     console.log(z);
//   }, 0);
// };

// let a = [1, 2, 3, 4, 5];
// a[10] = 10;
// console.log(a.length);

async function async1() {
  console.log("async1 start"); // 1
  await async2();
  console.log("async1 end"); // 2 (after await)
}

async function async2() {
  console.log("async2"); // 3
}

console.log("script start"); // 4

setTimeout(function () {
  console.log("setTimeout"); // 5 (macro task)
}, 0);

async1();

new Promise(function (resolve) {
  console.log("promise1"); // 6
  return resolve();
}).then(function () {
  console.log("promise2"); // 7 (microtask)
});

new Promise(function (resolve) {
  console.log("promise3"); // 6 again
  return resolve();
}).then(function () {
  console.log("promise4"); // 7 again (microtask)
});

console.log("script end"); // 8
