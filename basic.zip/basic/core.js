// call apply and bind

let name1 = {
  fName: "Tom",
  lName: "jak",
  //   printFullName: function () {
  //     console.log(this.fName + " " + this.lName);
  //   },
};
let printFullName = function (city, state) {
  console.log(this.fName + " " + this.lName + " " + city + " " + state);
};

// name1.printFullName();
printFullName.call(name1, "Deheradhun", "Utharakhand");

let name2 = {
  fName: "Jerry",
  lName: "jhill",
};

/**
 * with the help of call we can do function borroing from other object
 * when there are common function then that function written out side
 * the only difference between call and apply is the way we passing arrgument
 * bind method bind this printFullName to the object and return function
 */
// name1.printFullName.call(name2);
printFullName.call(name2, "Gandhi Nagar", "Gujarat");
printFullName.apply(name2, ["Gandhi Nagar1", "Gujarat1"]);
let print = printFullName.bind(name2, "Mumbai", "Maharastra");
print();

/**
 * function curring can be done in two types bind and closer
 */
// bind method
let multiply = function (x, y) {
  console.log(x * y);
};
//here we are setting the value of x as 2 permanent
let multiplyByTwo = multiply.bind(this, 2);
multiplyByTwo(3);
let multiplyByFour = multiply.bind(this, 4);
multiplyByFour(8);

// closure

let multiply1 = function (x) {
  return function (y) {
    console.log(x * y);
  };
};
let multiplyTwo = multiply1(2);
multiplyTwo(6);

/**
 * polyfill for bind method to create method similar to bind
 */

let printName = function () {
  console.log(this.fName + " " + this.lName);
};
Function.prototype.mybind = function (...args) {
  let obj = this;
  params = args.slice(1);
  return function (...args2) {
    // obj.call(args[0]);
    obj.apply(args[0], [...params, ...args2]);
  };
};

let printMyNma = printName.mybind(name1);
// console.log(printMyNma);
printMyNma();
