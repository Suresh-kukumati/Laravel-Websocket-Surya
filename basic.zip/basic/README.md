# 1 make counter that return object with increment,decrement and reset functions

<!-- console.log(counter.increment());
console.log(counter.increment());
console.log(counter.decrement());
console.log(counter.reset());
console.log(counter.decrement()); -->

# 2 check given string is palindrom

# 3 divided given array in n size chunks

# 4 find missing number from array

# 5 check if given string contain vowels and return count

# 6 impplement stack in javascript

# 7 flaten array
