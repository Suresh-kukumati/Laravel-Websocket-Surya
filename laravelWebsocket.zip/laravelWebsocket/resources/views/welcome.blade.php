<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Web Sockets</title>
</head>
<body>

    <script type="text/javascript">
        var conn = new WebSocket("ws://127.0.0.1:6001");

        conn.onopen = function(e){
            console.log("Connection established");
        }

        conn.onmessage = function(e){
            
        }
    </script>
    
</body>
</html>