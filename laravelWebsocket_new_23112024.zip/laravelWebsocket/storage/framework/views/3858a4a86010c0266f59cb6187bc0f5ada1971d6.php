<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WebSocket Client - Websolutionstuff</title>
</head>
<body>
    <h1>WebSocket Client</h1>
    <input type="text" id="message" placeholder="Type a message...">
    <button onclick="sendMessage()">Send</button>

    <script>
        let ws = new WebSocket('ws://localhost:6001');

        ws.onopen = function() {
            console.log('Connected to WebSocket server');
        };

        ws.onmessage = function(event) {
            console.log('Message from server: ' + event.data);
        };

        function sendMessage() {
            const message = document.getElementById('message').value;
            ws.send(message);
        }
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelWebsocket\resources\views/welcome.blade.php ENDPATH**/ ?>